﻿using System;

namespace XamathonDemo2
{
	public static class Constants
	{
		// Replace strings with your Azure Mobile App endpoint.
		public static string ApplicationURL = @"https://xamathondemo2.azurewebsites.net";
	}
}

